# :fontawesome-solid-indent: Konular

## :fontawesome-solid-indent: Konu Listesi

Mobil Yaka uygulamasında görünecek Ramak Kala kategorileri burada gösterilir, düzenlenir ya da silinir.

![](./images/konuListesi.png)

## Yeni Konu Oluştur

### Konu Tanımla

| Özellik              | Açıklama                                                     |
| -------------------- | ------------------------------------------------------------ |
| Konu Adı             | -                                                            |
| Aktifleştirme Durumu | Aktif olması durumunda konu, Ramak Kala modülünde görünür, Pasif olması durumunda görünmez. |

