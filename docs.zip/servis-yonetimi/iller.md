# :fontawesome-solid-bus: Servis Yönetimi

## :fontawesome-solid-city: İl Ekle & Düzenle

Firmanızdaki servislerin hizmet verdiği il bilgileri oluşturulur, düzenlenir ya da silinir.

![](./images/ilEkleDuzenle.png){: style="height:384px;width:568px"}
