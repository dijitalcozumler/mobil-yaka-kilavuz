# Sürüm Notları

## Mobil Yaka Sürüm Notları

### 1.27.5 <small>_10 Mart 2022</small>

:mobile_phone: Mobil Uygulama

- Uygulama açılış hızı iyileştirildi
- Ramak Kala’dan eklenen resimleri kırpma özelliği eklendi.
- Servis Güzergahları ekranında servislere göre arama yapılabilir.

#### :gear: Yönetim Paneli

- Excel dosyası kullanarak “Çoklu Kullanıcı Tanımlama” işlemi kolaylaştırıldı.
- Yönetim Paneli üzerinde yetki yapısı oluşturuldu. “Yetkilendirme” sayfasından roller oluşturabilir ve bu rollere belirli modüller üzerinde yetki tanımlayabilirsiniz. Örneğin; Eğitim Moderatörleri isimli bir rol oluşturarak, bu roldeki kullanıcıların yönetim panelinde sadece “Eğitim” modülüne erişmesini sağlayabilirsiniz.

#### :beetle: Altyapı İyileştirmeleri ve Buglar

- Modüller kapanabilir / açılabilir hâle getirildi. Örneğin, Oylama modülü kullanılmayacaksa mobil uygulamadan ve yönetim panelinden kaldırılabilir. Böyle bir ihtiyacınız olması durumunda dijitalcozumler@datamarket.com.tr adresinden bizlerle iletişime geçebilirsiniz.
- Eğitime eklenmiş yatay (landscape) formatındaki PDF dosyaların görüntülenmesini engelleyen bir hata düzeltildi.
- Profil resmi  güncellenirken oluşan çökme giderildi.
- Tebrikler modülü, bildirim tiplerine eklendi.
- Şirket Takvimi modülünde tarihin tam görüntülenememesi düzeltildi.
- Kullanıcıya gelen bildirime tıklandığında ilgili modülün açılmasını engelleyen bir hata giderildi.
- Haberler, Eğitim ve Hakkımızda modüllerinde çeşitli iyileştirmeler yapıldı.

### 1.27.4 <small>_20 Ocak 2022</small>

#### :mobile_phone: Mobil Uygulama

- Check-in özelliği eklendi
- Dış Bağlantılar'a eklenen linkler, mobil uygulamadan çıkmadan, uygulama içerisinde görüntülenebilir.

#### :gear: Yönetim Paneli

- Kurumsal eğitimlerin istediğiniz kişilere ve/veya gruplara atanabilmesi sağlandı.
- Kullanıcı düzenleme ekranından, kullanıcı profil fotoğraflarının değiştirilebilmesi sağlandı.

#### :bar_chart: Raporlama

- Firma Raporları’nda Tebrikler modülüne ait veriler raporlanabilir hale getirildi.

#### :beetle: Altyapı İyileştirmeleri ve Buglar

- Uygulama açılış hızı optimize edildi.
- Haberlerin girilme tarihinin yanlış görünmesine sebep olan bir hata düzeltildi.
- Eğitimler, Anketler ve Servis Güzergahları modüllerinde iyileştirmeler yapıldı.