# Sürüm Notları

## Mobil Yaka Sürüm Notları

### 1.XX.X <small>_20 Ocak 2022</small>

- Sürüm notu
- Not

### 1.24.4 <small>_20 Ocak 2022</small>

#### :mobile_phone: Mobil Uygulama

- Check-in özelliği eklendi
- Dış Bağlantılar'a eklenen linkler, mobil uygulamadan çıkmadan, uygulama içerisinde görüntülenebilir.

#### :gear: Uygulama Paneli

- Kurumsal eğitimlerin istediğiniz kişilere ve/veya gruplara atanabilmesi sağlandı.
- Kullanıcı düzenleme ekranından, kullanıcı profil fotoğraflarının değiştirilebilmesi sağlandı.

#### :bar_chart: Raporlama

- Firma Raporları’nda Tebrikler modülüne ait veriler raporlanabilir hale getirildi.

#### :beetle: Altyapı İyileştirmeleri ve Buglar

- Uygulama açılış hızı optimize edildi.
- Haberlerin girilme tarihinin yanlış görünmesine sebep olan bir hata düzeltildi.
- Eğitimler, Anketler ve Servis Güzergahları modüllerinde iyileştirmeler yapıldı.