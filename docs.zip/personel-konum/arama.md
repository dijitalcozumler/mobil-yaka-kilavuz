# :fontawesome-solid-map-marked-alt: Personel Konum

## :fontawesome-solid-map-marked-alt: Arama

Mobil Yaka uygulaması içerisinden Check-in yapmış kullanıcıların listelenmesini sağlar. Bu sayfada sadece bir kişinin konum bilgisi gösterilir.

![](./images/arama.png)